"""
Module that defines classes for matchers other than gazetteers which match e.g. regular expressions
of strings or annotations.
"""


class StringRegexMatcher:
    """
    NOT YET IMPLEMENTED
    """

    pass


# class AnnotationRegexMatcher:
#    """ """
#    pass
