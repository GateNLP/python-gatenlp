"""
Package for annotators, and other things related to processing documents.
"""