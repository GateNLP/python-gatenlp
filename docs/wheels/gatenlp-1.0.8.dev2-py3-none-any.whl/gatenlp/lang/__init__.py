"""
Subpackage for future language-specific resources and annotators
"""
