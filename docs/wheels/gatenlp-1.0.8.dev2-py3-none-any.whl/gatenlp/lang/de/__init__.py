"""
Subpackage for German language resources and annotators.
"""
