"""
Subpackage for English language ressources and annotators.
"""
